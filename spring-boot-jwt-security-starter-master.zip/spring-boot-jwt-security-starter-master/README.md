### spring-boot-jwt-security-starter
Base url: http://localhost:8080/api

Open url: http://localhost:8080/api/signup http://localhost:8080/api/signin <br/>
Secured url: http://localhost:8080/api/users
