package com.zavada.exception;

//@ControllerAdvice
public class ServerExceptionHandler {

//	@ExceptionHandler(value = Exception.class)
//	public ResponseEntity<ErrorMessage> handleExceptions(Exception ex, WebRequest req) {
//		ErrorMessage errorMessage = new ErrorMessage(ex.getMessage());
//		return new ResponseEntity<ErrorMessage>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
}
