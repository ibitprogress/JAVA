package com.zavada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityJWTStarterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityJWTStarterApplication.class, args);
    }
}
