drop database if exists mydb_1;
create database mydb_1 char set 'utf8';